# Totem FlexMedia Sprint 3

## Objetivo: 

Nesta sprint o foco foi em persistência de dados e gerenciamento de registros. 
O objetivo foi fazer com que os dados não se percam ao fechar o programa, além de permitir 
editar e excluir informações já cadastradas.

## O que foi implementado:

*Salvamento automático em um arquivo dados.json sempre que um registro é cadastrado, editado ou excluído

*Carregamento dos dados ao iniciar o programa, recuperando tudo que foi salvo anteriormente

*Tratamento de erros caso o arquivo não exista ou esteja corrompido

*Funcionalidade de edição, onde o usuário escolhe um registro, vê os dados atuais e pode alterar título, tipo e descrição

*Funcionalidade de exclusão com confirmação antes de remover o registro

*Código organizado em dois arquivos: funcoes.py com toda a lógica e main.py responsável apenas pelo menu

## Membros: 

Carolina Cordeiro Silva | RM 564234

Gabriel Henrique Pioli | RM 567724

João Victor Tozzatti Matiro | RM 567510

Pedro Diagro Lopes | RM 568393

Feito por: 
João Victor
