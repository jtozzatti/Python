informacoes = []

def adicionar_informacao():
    titulo = input("Digite o título: ").strip()
    while titulo == "":
        titulo = input("O título não pode estar vazio. Digite novamente: ").strip()

    tipo = input("Digite o tipo (educativo, cultural ou lazer): ").lower()
    while tipo not in ["educativo", "cultural", "lazer"]:
        tipo = input("Tipo inválido. Digite (educativo, cultural ou lazer): ").lower()

    descricao = input("Digite a descrição: ")

    informacoes.append({
        "titulo": titulo,
        "tipo": tipo,
        "descricao": descricao
    })
    print("\nInformação cadastrada com sucesso!\n")

def listar_informacoes():
    if not informacoes:
        print("\nNenhuma informação cadastrada.\n")
    else:
        print("\n--- Informações Cadastradas ---")
        for i, info in enumerate(informacoes, start=1):
            print(f"{i}. Título: {info['titulo']}")
            print(f"   Tipo: {info['tipo']}")
            print(f"   Descrição: {info['descricao']}\n")

def pesquisar_por_tipo():
    tipo = input("Digite o tipo para pesquisar (educativo, cultural ou lazer): ").lower()
    if tipo not in ["educativo", "cultural", "lazer"]:
        print("\nTipo inválido.\n")
        return

    encontrados = [info for info in informacoes if info["tipo"] == tipo]
    if encontrados:
        print(f"\n--- Informações do tipo '{tipo}' ---")
        for i, info in enumerate(encontrados, start=1):
            print(f"{i}. Título: {info['titulo']}")
            print(f"   Descrição: {info['descricao']}\n")
    else:
        print(f"\nNenhuma informação do tipo '{tipo}' encontrada.\n")

# Menu principal
while True:
    print("=== Totem FlexMedia ===")
    print("1 - Cadastrar informação")
    print("2 - Listar informações cadastradas")
    print("3 - Pesquisar informações por tipo")
    print("0 - Sair")
    opcao = input("Escolha uma opção: ")

    if opcao == "1":
        adicionar_informacao()
    elif opcao == "2":
        listar_informacoes()
    elif opcao == "3":
        pesquisar_por_tipo()
    elif opcao == "0":
        print("\nSaindo do programa. Até mais!")
        break
    else:
        print("\nOpção inválida. Tente novamente.\n")
