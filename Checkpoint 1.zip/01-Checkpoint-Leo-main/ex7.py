#Login simples

while True:
    usuario = input("Digite o seu usuário: ")
    senha = input("Digite a sua senha: ")

    if usuario == "admin" and senha == "1234":
        print("Acesso permitido.")
    else:
        print("Acesso negado.")

   