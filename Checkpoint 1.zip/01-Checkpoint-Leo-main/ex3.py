#Maioridade

while True:
    numero = int(input("Digite sua idade: "))

    if numero > 18:
        print("Você é maior de idade.")
    elif numero < 18:
        print("Você é menor de idade.")
    else:
        print("Você tem exatamente 18 anos.")