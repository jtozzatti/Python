#Conversão de temperatura

while True:
    numero = int(input("Digite uma temperatura em °C: "))

    if numero < 0:
        print("Congelante")
    elif 0 <= numero <= 30:
        print("Agradável")
    else:
        print("Quente")




