#Calculadora simples

while True:
    
    numero1 = int(input("Digite o primeiro número: "))
    numero2 = int(input("Digite o segundo número: "))

    operacao = input("Digite a operação (+, -, *, /): ")

    if operacao == "+":
        resultado = numero1 + numero2
        print("Resultado:", resultado)
    elif operacao == "-":
        resultado = numero1 - numero2
        print("Resultado:", resultado)
    elif operacao == "*":
        resultado = numero1 * numero2
        print("Resultado:", resultado)
    elif operacao == "/":
        if numero2 != 0:
            resultado = numero1 / numero2
            print("Resultado:", resultado)
        else:
            print("Erro: Divisão por zero não é permitida.")
    else:
        print("Operação inválida. Digite apenas +, -, * ou /.")
