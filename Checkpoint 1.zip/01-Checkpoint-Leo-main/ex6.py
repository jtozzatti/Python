#Desconto em produto

while True:
    valor = float(input("Digite o valor do produto: R$ "))

    if valor > 100:
        desconto = valor * 0.10
        preco_final = valor - desconto
        print(f"Preço com desconto de 10%: R$ {preco_final:.2f}")
    else:
        print(f"Preço sem desconto: R$ {valor:.2f}")
