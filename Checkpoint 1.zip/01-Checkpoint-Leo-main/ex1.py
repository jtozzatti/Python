#Número positivo ou negativo

while True:
    numero = int(input("Digite um número inteiro: "))

    if numero > 0:
        print("O número é positivo.")
    elif numero < 0:
        print("O número é negativo.")
    else:
        print("O número é zero.")