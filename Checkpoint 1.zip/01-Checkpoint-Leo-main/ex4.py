 #Nota de aprovação

while True:
    numero = int(input("Olá Aluno!!! Digite sua nota (0 a 10): "))
    if numero >= 6:
        print("Aprovado.")
    else:
        print("Reprovado.")
