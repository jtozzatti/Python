# Par ou múltiplo de 5

while True:
    numero = int(input("Digite um número inteiro: "))

    if numero % 2 == 0 and numero % 5 == 0:
        print("Número par e multiplo de 5!")

    elif numero % 2 == 0:
        print("Número par!")

    elif numero % 5 == 0:
        print("Múltiplo de 5")
        
    else:
        print("Outro número")
