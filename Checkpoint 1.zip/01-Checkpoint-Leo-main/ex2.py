#Par ou ímpar

while True:
    numero = int(input("Digite um número: "))

    if numero == 0:
        print("O número é zero.")
    elif numero % 2 == 0:
        print("O número é par.")
    else:
        print("O número é ímpar.")

