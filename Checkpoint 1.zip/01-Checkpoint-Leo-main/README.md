# 01-Checkpoint-Leo
Exercicios para meu checkpoint
